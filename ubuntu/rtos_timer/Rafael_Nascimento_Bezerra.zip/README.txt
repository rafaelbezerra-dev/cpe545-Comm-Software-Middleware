/* TO RUN THE PROGRAM OPEN THE TERMINAL AND TYPE:
 *    gcc -std=gnu99 -pthread -o run main.c
 *    ./run
 * -------------------------------------------------
 * CODED BY: RAFAEL NASCIMENTO BEZERRA
 */
